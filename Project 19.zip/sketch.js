var PLAY = 1;
var END = 0;
var gameState = PLAY;

var ghost, ghostImage;
var ground, invisibleGround, forestImage;

var candyGroup, candy1, candy2, candy3;
var enemyGroup, enemy2, enemy1,enemy3;
var score=0;
var life=7;


function preload(){
  ghostImage = loadImage("Ghost.png")
  forestImage = loadImage("Forest.jpg");
  
  candy2 = loadImage("Candy2.png");
  candy1 = loadImage("Candy1.png");
  candy3 = loadImage("Candy3.png");
  
  enemy2 = loadImage("Enemy2.png");
  enemy1 = loadImage("Enemy1.png");
  enemy3 = loadImage("Enemy3.png");
  
}

function setup() {
  createCanvas(400, 400);
  ghost = createSprite(50,380,20,50);
  ghost.addImage(ghostImage);
  ghost.scale = 0.1;
  
  ground = createSprite(0,390,1200,10);
  ground.x = ground.width /2;
  ground.velocityX = -(6 + 3*score/100);
  ground.shapeColor = "darkBlue"
  
  candyGroup = new Group();
  enemyGroup = new Group();
  
  score = 0;
  life = 7;
}

function draw() {
  background("lightBlue");
  textSize(20);
  fill(255);
  text("Score: "+ score, 300,40);
  text("Lives:" + life, 200,40);
  
  drawSprites();
  if (gameState===PLAY){
  
    if(candyGroup.isTouching(ghost)) {
      score = score + 1;
      candyGroup.destroyEach()
    }
     
    if(score >= 0){
      ground.velocityX = -6;
    }else{
      ground.velocityX = -(6 + 3*score/100);
    }
  
    if(keyDown("space") && ghost.y >= 339) {
      ghost.velocityY = -12;
    }
  
    ghost.velocityY = ghost.velocityY + 0.8
  
    if (ground.x < 0){
      ground.x = ground.width/2;
    }
  
    ghost.collide(ground);
    
    spawnCandy();
    spawnEnemy();
  
   if(enemyGroup.isTouching(ghost)){
        life=life-1
     enemyGroup.destroyEach()
   }
     if(life===0) {
       gameState=END
     }
       
  }
  
  else if (gameState === END ) {

    ground.velocityX = 0;
    ghost.velocityY = 0;
    enemyGroup.setVelocityXEach(0);
    candyGroup.setVelocityXEach(0);

    candyGroup.setLifetimeEach(-1);
    enemyGroup.setLifetimeEach(-1);
    
    if(gameState === END) {
      reset();
    }
  }
}

function spawnEnemy() {
  
  if (frameCount % 80 === 0) {
    var enemy = createSprite(300,320,40,10);
   
    var rand = Math.round(random(1,3));
    switch(rand) {
      case 1: enemy.addImage(enemy2);
              break;
      case 2: enemy.addImage(enemy1);
              break;
      case 3: enemy.addImage(enemy3);
              break;
    }
    
    enemy.scale = 0.1
     
    enemy.lifetime = 150;
    
    enemyGroup.add(enemy);
  }
  
}

function spawnCandy() {
  if(frameCount % 60 === 0) {
    var candy = createSprite(600,365,10,40);    
    
    var rand = Math.round(random(1,3));
    switch(rand) {
      case 1: candy.addImage(candy2);
              break;
      case 2: candy.addImage(candy1);
              break;
      case 3: candy.addImage(candy3);
              break;
    }
        
    candy.velocityX = -(6 + 3*score/100);         
    candy.scale = 0.07;
    candy.lifetime = 150;
    
    candyGroup.add(candy);
  }
}

function reset() {
  gameState = PLAY;
  candyGroup.destroyEach();
  enemyGroup.destroyEach();
  life=7
  score = 0;
}